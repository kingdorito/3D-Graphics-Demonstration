#include "Rasteriser.h"

Rasteriser app;

string Rasteriser::ModelPath()
{
	char buf[256];
	GetCurrentDirectoryA(256, buf);
	return std::string(buf) + '\\';
}

bool Rasteriser::Initialise()
{
	_modelpath="";
	_modelpath = ModelPath() + "\\cube.md2";

	if (!MD2Loader::LoadModel(_modelpath.c_str(), _model,
		&Model::AddPolygon,
		&Model::AddVertex))
	{
		return false;
	}
	_model;
	
	Camera temp(0, 0, 0, Vertex(0, 0, -50, 1)); 
	_camera = temp;
	return true;
}

void Rasteriser::DrawWireFrame(Bitmap &bitmap)
{

	//DrawWireFrame method

	// 1. Get the Polygons from the _model and store it to a local list std::vector<Polygon3D>
	std::vector<Polygon3D> polygons(_model.GetPolygons());

	// 2. Get the polygons size (How many there are)
	int numOfPolygons = polygons.size();

	// 3. Get the current transformations from the _model and store it to a local list std::vector<Vertex>
	std::vector<Vertex> transformations(_model.GetTransform());

	// 4. Create a Pen while store the current pen
	HPEN hPen = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
	HGDIOBJ oldPen = SelectObject(bitmap.GetDC(), hPen);

	//Make a loop for 0 till you reach the polygon size. For each polygon get the Index of it and then the Vertex that corresponds to this index.
	
	for (int i = 0; i < numOfPolygons; i++)
	{
		Polygon3D polygon = polygons[i];
		int polygonIndex0 = polygons[i].GetIndex(0), polygonIndex1 = polygons[i].GetIndex(1), polygonIndex2 = polygons[i].GetIndex(2);
		Vertex vertex0 = transformations[polygonIndex0], vertex1 = transformations[polygonIndex1], vertex2 = transformations[polygonIndex2];

		MoveToEx(bitmap.GetDC(), vertex0.GetIntX(), vertex0.GetIntY(), NULL);
		LineTo(bitmap.GetDC(), vertex1.GetIntX(), vertex1.GetIntY());
		LineTo(bitmap.GetDC(), vertex2.GetIntX(), vertex2.GetIntY());
		LineTo(bitmap.GetDC(), vertex0.GetIntX(), vertex0.GetIntY());
	}
}



void Rasteriser::GenerateProjectionMatrix(float d, float aspectRatio)
{
	// Perspective projection
	Matrix perspective{ d / aspectRatio, 0, 0, 0,
						0, d, 0, 0,
						0, 0, d, 0,
						0, 0, 1, 0 };
	_perspectiveTransform = perspective;
}

void Rasteriser::GenerateScreenMatrix(float d, int width, int height) // ScrenTransformation
{
	Matrix view{ float(width) / 2, 0, 0, float(width) / 2,
				 0, float(-height) / 2, 0, float(height) / 2,
				 0, 0, d / 2, d / 2,
				 0, 0, 0, 1 };
	_screenTransform = view;
}

//Method for Backface Culling. 
void Rasteriser::BackfaceCulling(Bitmap& bitmap)
{
	//Get the polygons from a list.
	std::vector<Polygon3D> polygons(_model.GetPolygons());

	//Get the polygons size (How many there are)
	int numOfPolygons = polygons.size();

	//Get the current transformations from the _model and store it to a local list std::vector<Vertex>
	std::vector<Vertex> transformations(_model.GetTransform());

	//Create a Pen while store the current pen
	HPEN hPen = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
	HGDIOBJ oldPen = SelectObject(bitmap.GetDC(), hPen);

	//Make a loop for 0 till you reach the polygon size. For each polygon get the Index of it and then the Vertex that corresponds to this index.
	for (int i = 0; i < numOfPolygons; i++)
	{
		if (!polygons[i].GetCull())
		{
			Polygon3D polygon = polygons[i];
			int polygonIndex0 = polygons[i].GetIndex(0), polygonIndex1 = polygons[i].GetIndex(1), polygonIndex2 = polygons[i].GetIndex(2);
			Vertex vertex0 = transformations[polygonIndex0], vertex1 = transformations[polygonIndex1], vertex2 = transformations[polygonIndex2];

			MoveToEx(bitmap.GetDC(), vertex0.GetIntX(), vertex0.GetIntY(), NULL);
			LineTo(bitmap.GetDC(), vertex1.GetIntX(), vertex1.GetIntY());
			LineTo(bitmap.GetDC(), vertex2.GetIntX(), vertex2.GetIntY());
			LineTo(bitmap.GetDC(), vertex0.GetIntX(), vertex0.GetIntY());
		}
	}
}

void Rasteriser::Update(Bitmap &bitmap)  
{
	
	float aspectRatio = float(float(bitmap.GetWidth()) / float(bitmap.GetHeight()));
	GenerateProjectionMatrix(1, aspectRatio);
	GenerateScreenMatrix(1, bitmap.GetWidth(), bitmap.GetHeight());
	// Displaying the code
	//Update Method. 
	//Add 100 to the frame count 
	if (_frameCount < 50)
	{
		_phase = RenderPhase::Start;
		_displayText = L"Wireframe";
	}
	else if (_frameCount < 150)
	{
		_phase = RenderPhase::WireframeScaleX;
		_displayText = L"Wireframe: X Axis Scale";
		_frameScaleY = 0; //0 the next action before it begins. 
		//The action is initialized in the rasterizer header, but till it gets here the value is more than 1. 
	}
	//Apply the same.
	else if (_frameCount < 250)
	{
		_phase = RenderPhase::WireframeScaleY;
		_displayText = L"Wireframe: Y Axis Scale";
		_frameScaleZ = 0;
	}
	else if (_frameCount < 350)
	{
		_phase = RenderPhase::WireframeScaleZ;
		_displayText = L"Wireframe: Z Axis Scale";
		_framesRotateX = 0;
	}
	else if (_frameCount < 450)
	{
		_phase = RenderPhase::WireframeRotateX;
		_displayText = L"Wireframe: Rotation X Axis";
		_framesRotateY = 0;
	}
	else if (_frameCount < 550)
	{
		_phase = RenderPhase::WireframeRotateY;
		_displayText = L"Wireframe: Rotation Y Axis";
		_framesRotateZ = 0;
	}
	else if (_frameCount < 650)
	{
		_phase = RenderPhase::WireframeRotateZ;
		_displayText = L"Wireframe: Rotation Z Axis";
		_framesTranslationX = 0; 
	}
	else if (_frameCount < 750)
	{
		_phase = RenderPhase::WireframeTranslationX;
		_displayText = L"Wireframe: Translation on X Axis";
		_framesTranslationY = 0; 
	}
	else if (_frameCount < 850)
	{
		_phase = RenderPhase::WireframeTranslationY;
		_displayText = L"Wireframe: Translation on Y Axis";
		_framesTranslationZ = 0; 
	}
	else if (_frameCount < 950)
	{
		_phase = RenderPhase::WireframeTranslationZ;
		_displayText = L"Wireframe: Translation on Z Axis";
		_framesBackfaceCullingScaleX = 0;
		
	}
	//Backface Culling
	//Backface Culling phase: Scale 
	else if (_frameCount < 1050)
	{

		_phase = RenderPhase::BackfaceCullingScaleX; 
		_displayText = L"Wireframe: Backface Culling Scale X";
		_framesBackfaceCullingScaleY = 0;
		
	}
	else if (_frameCount < 1150)
	{
		_phase = RenderPhase::BackfaceCullingScaleY;
		_displayText = L"Wireframe: Backface Culling Scale Y";
		_framesBackfaceCullingScaleZ = 0;
	}
	else if (_frameCount < 1250)
	{
		_phase = RenderPhase::BackfaceCullingScaleZ;
		_displayText = L"Wireframe: Backface Culling Scale Z";
		_framesBackfaceCullingRotateX = 0;

	}

	//Backface Culling phase: Rotate
	else if (_frameCount < 1350)
	{
		_phase = RenderPhase::BackfaceCullingRotateX;
		_displayText = L"Wireframe: Backface Culling Rotate X";
		_framesBackfaceCullingRotateY = 0;

	}
	else if (_frameCount < 1450)
	{
		_phase = RenderPhase::BackfaceCullingRotateY;
		_displayText = L"Wireframe: Backface Culling Rotate Y";
		_framesBackfaceCullingRotateZ = 0;
	}
	else if (_frameCount < 1550)
	{
		_phase = RenderPhase::BackfaceCullingRotateZ;
		_displayText = L"Wireframe: Backface Culling Rotate Z";
		_framesBackfaceCullingTranslateX = 0;

	}

	//Backface Culling phase: Tranlation
	else if (_frameCount < 1650)
	{
		_phase = RenderPhase::BackfaceCullingTranslateX;
		_displayText = L"Wireframe:	Backface Culling Translation X";
		_framesBackfaceCullingTranslateY = 0;

	}
	else if (_frameCount < 1750)
	{
		_phase = RenderPhase::BackfaceCullingTranslateY;
		_displayText = L"Wireframe: Backface Culling Translation Y";
		_framesBackfaceCullingTranslateZ = 0;
		
	}
	else if (_frameCount < 1850)
	{
		_phase = RenderPhase::BackfaceCullingTranslateZ;
		_displayText = L"Wireframe: Backface Culling Translation Z";

	}
	_frameCount++;

	//Adding 1 so the cube constantly change values. 
	//Wireframe Scale
	_framesScaleX++;
	_frameScaleY++;
	_frameScaleZ++;
	
	//Wireframe Rotate
	_framesRotateX++;
	_framesRotateY++;
	_framesRotateZ++;

	//Wireframe Translate.
	_framesTranslationX++;
	_framesTranslationY++;
	_framesTranslationZ++;

	//Backface Culling Scale
	_framesBackfaceCullingScaleX++;
	_framesBackfaceCullingScaleY++;
	_framesBackfaceCullingScaleZ++;

	//Backface Culling Rotate 
	_framesBackfaceCullingRotateX++;
	_framesBackfaceCullingRotateY++;
	_framesBackfaceCullingRotateZ++;
	
	//Backface Culling Translate
	_framesBackfaceCullingTranslateX++;
	_framesBackfaceCullingTranslateY++;
	_framesBackfaceCullingTranslateZ++;
}

void Rasteriser::Render(Bitmap &bitmap)   
{ 
	bitmap.Clear(RGB(0, 0, 0));
	switch (_phase)
	{
		//Cube size is 0.010. 
	case RenderPhase::Start:
	{
		_modelTransform = Matrix::YRotationMatrix(0);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		DrawWireFrame(bitmap);
		break;
	}
	case RenderPhase::WireframeScaleX:
	{
		//Adding the appropriate Matrix table from the Matrix class, the variable that is declared and multiplying it by 0.010 
		//Same applies to every other method. 
		_modelTransform = Matrix::ScalingMatrixX(_framesScaleX * cubeSize); 
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		DrawWireFrame(bitmap);
		break;
	}
	case RenderPhase::WireframeScaleY:
	{
		_modelTransform = Matrix::ScalingMatrixY(_frameScaleY * cubeSize);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		DrawWireFrame(bitmap);
		break;
	}
	case RenderPhase::WireframeScaleZ:
	{
		_modelTransform = Matrix::ScalingMatrixZ(_frameScaleZ * cubeSize);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		DrawWireFrame(bitmap);
		break;
	}
	case RenderPhase::WireframeRotateX:
	{
		_modelTransform = Matrix::XRotationMatrix(_framesRotateX * cubeSize);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		DrawWireFrame(bitmap);
		break;
	}
	case RenderPhase::WireframeRotateY:
	{
		_modelTransform = Matrix:: YRotationMatrix(_framesRotateY * cubeSize);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		DrawWireFrame(bitmap);
		break;
	}
	case RenderPhase::WireframeRotateZ:
	{
		_modelTransform = Matrix::ZRotationMatrix(_framesRotateZ * cubeSize);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		DrawWireFrame(bitmap);
		break;
	}
	case RenderPhase::WireframeTranslationX:
	{
		//Adding the translation Matrix table from the Matrix class. Adding the variable on the X value while 0 the y and the z. 
		_modelTransform = Matrix::TranslationMatrix(_framesTranslationX, 0, 0);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		DrawWireFrame(bitmap);
		break;
	}
	case RenderPhase::WireframeTranslationY:
	{
		_modelTransform = Matrix::TranslationMatrix(0, _framesTranslationY, 0);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		DrawWireFrame(bitmap);
		break;
	}
	case RenderPhase::WireframeTranslationZ:
	{
		_modelTransform = Matrix::TranslationMatrix(0, 0, _framesTranslationZ);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		DrawWireFrame(bitmap);
		break;
	}
	//BackfaceCulling implementantion in Rasteriser.
	//Scaling Phase. 
	case RenderPhase::BackfaceCullingScaleX:
	{
		_modelTransform = Matrix::ScalingMatrixX(_framesBackfaceCullingScaleX * cubeSize);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		_model.CalculateBackfaces(_camera); //Calling the camera to show the changes, on the CalculateBackfaces method in the Model class.
		BackfaceCulling(bitmap);
		break;
	}
	case RenderPhase::BackfaceCullingScaleY:
	{
		_modelTransform = Matrix::ScalingMatrixY(_framesBackfaceCullingScaleY * cubeSize);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		_model.CalculateBackfaces(_camera);
		BackfaceCulling(bitmap);
		break;
	}
	case RenderPhase::BackfaceCullingScaleZ:
	{
		_modelTransform = Matrix::ScalingMatrixZ(_framesBackfaceCullingScaleZ * cubeSize);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		_model.CalculateBackfaces(_camera);
		BackfaceCulling(bitmap);
		break;
	}
	//Rotation Phase 
	case RenderPhase::BackfaceCullingRotateX:
	{
		_modelTransform = Matrix::XRotationMatrix(_framesBackfaceCullingRotateX * cubeSize);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		_model.CalculateBackfaces(_camera);
		BackfaceCulling(bitmap);
		break;
	}
	case RenderPhase::BackfaceCullingRotateY:
	{
		_modelTransform = Matrix::YRotationMatrix(_framesBackfaceCullingRotateY * cubeSize);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		_model.CalculateBackfaces(_camera);
		BackfaceCulling(bitmap);
		break;
	}
	case RenderPhase::BackfaceCullingRotateZ:
	{
		_modelTransform = Matrix::ZRotationMatrix(_framesBackfaceCullingRotateZ * cubeSize);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		_model.CalculateBackfaces(_camera);
		BackfaceCulling(bitmap);
		break;
	}
	//Translate Phase
	case RenderPhase::BackfaceCullingTranslateX:
	{
		_modelTransform = Matrix::TranslationMatrix(_framesBackfaceCullingTranslateX,0,0);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		_model.CalculateBackfaces(_camera);
		BackfaceCulling(bitmap);
		break;
	}
	case RenderPhase::BackfaceCullingTranslateY:
	{
		_modelTransform = Matrix::TranslationMatrix( 0, _framesBackfaceCullingTranslateY,0);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		_model.CalculateBackfaces(_camera);
		BackfaceCulling(bitmap);
		break;
	}
	case RenderPhase::BackfaceCullingTranslateZ:
	{
		_modelTransform = Matrix::TranslationMatrix(0, 0, _framesBackfaceCullingTranslateZ);
		_model.ApplyTransformToLocalVertices(_modelTransform);
		_model.ApplyTransformToTransformedVertices(_camera.GetCameraMatrix());
		_model.ApplyTransformToTransformedVertices(_perspectiveTransform);
		_model.Dehomogenize();
		_model.ApplyTransformToTransformedVertices(_screenTransform);

		_model.CalculateBackfaces(_camera);
		BackfaceCulling(bitmap);
		break;
	}
	default:
		break;
	}
	DrawString(bitmap, _displayText.c_str());
	
}
void Rasteriser::DrawString(const Bitmap& bitmap, LPCTSTR text)
{
	HDC hdc = bitmap.GetDC();
	HFONT hFont, hOldFont;

	// Retrieve a handle to the variable stock font.  
	hFont = hFont = CreateFont(48, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS,
		CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, TEXT("Myfont"));

	// Select the variable stock font into the specified device context. 
	if (hOldFont = (HFONT)SelectObject(hdc, hFont))
	{
		SetTextColor(hdc, RGB(255, 255, 255));
		SetBkColor(hdc, RGB(0, 0, 0));

		// Display the text string.  
		TextOut(hdc, 10, 10, text, lstrlen(text));

		// Restore the original font.        
		SelectObject(hdc, hOldFont);
	}
	DeleteObject(hFont);
}