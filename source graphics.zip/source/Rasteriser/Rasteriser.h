#pragma once
#define _USE_MATH_DEFINES
#include <vector>
#include <time.h>
#include <math.h>
#include "Framework.h"
#include "Vertex.h"
#include "Matrix.h"
#include "Model.h"
#include "Polygon3d.h"
#include "MD2Loader.h"
#include "Camera.h"
#include "Vector3D.h"

enum class RenderPhase
{
	Start,
	WireframeScaleX,
	WireframeScaleY,
	WireframeScaleZ,
	WireframeRotateX,
	WireframeRotateY,
	WireframeRotateZ,
	WireframeTranslationX,
	WireframeTranslationY,
	WireframeTranslationZ, 
	BackfaceCullingScaleX,
	BackfaceCullingScaleY,
	BackfaceCullingScaleZ,
	BackfaceCullingRotateX,
	BackfaceCullingRotateY,
	BackfaceCullingRotateZ,
	BackfaceCullingTranslateX,
	BackfaceCullingTranslateY,
	BackfaceCullingTranslateZ
};
class Rasteriser : public Framework
{
public:
	string ModelPath();
	bool Initialise();
	void Update(Bitmap& bitmap);
	void Render(Bitmap& bitmap);

	void DrawWireFrame(Bitmap& bitmap);
	void DrawSolid(Bitmap& bitmap);
	void GenerateProjectionMatrix(float d, float aspectRatio);
	void GenerateScreenMatrix(float d, int width, int height);
	void BackfaceCulling(Bitmap& bitmap);
	void DrawString(const Bitmap& bitmap, LPCTSTR text);
	float x = 0;
private:
	Model _model;
	Camera _camera;
	Matrix _modelTransform;
	Matrix _perspectiveTransform;
	Matrix _screenTransform;
	string _modelpath;
	float _angle;

	// For displaying purposes
	float _frameCount{ 0 };
	//Wireframe Values
	//Values initialized for scaling 
	float _framesScaleX{ 0 };
	float _frameScaleY{ 0 };
	float _frameScaleZ{ 0 };
	//Values initialized for rotation
	float _framesRotateX{ 0 };
	float _framesRotateY{ 0 };
	float _framesRotateZ{ 0 };
	//Values initialized for translation 
	float _framesTranslationX{ 0 };
	float _framesTranslationY{ 0 };
	float _framesTranslationZ{ 0 };
	//Values initialized for scaling (Backface Culling)
	float _framesBackfaceCullingScaleX, _framesBackfaceCullingScaleY, _framesBackfaceCullingScaleZ{ 0 };
	//Rotate
	float _framesBackfaceCullingRotateX, _framesBackfaceCullingRotateY, _framesBackfaceCullingRotateZ{ 0 };
	//Translate
	float _framesBackfaceCullingTranslateX, _framesBackfaceCullingTranslateY, _framesBackfaceCullingTranslateZ{ 0 };
	
	//Size for every action 
	float cubeSize{ 0.010 }; 

	std::wstring _displayText = L"";
	RenderPhase _phase = RenderPhase::Start;
};

