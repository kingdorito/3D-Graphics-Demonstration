#include "Model.h"

Model::Model()
{
	_polygons.clear();
	_vertices.clear();
	_transform.clear();

}


//Copy Constructor
Model::Model(const Model& m)
{
	_polygons = m.GetPolygons();
	_vertices = m.GetVertices();
	_transform = m.GetTransform();

}

Model::~Model()
{

}

//Accessors and mutators
const std::vector<Polygon3D>& Model::GetPolygons() const
{
	return _polygons;
}

const std::vector<Vertex>& Model::GetVertices() const
{
	return _vertices;
}

const std::vector<Vertex>& Model::GetTransform() const
{
	return _transform;
}


size_t Model::GetPolygonCount() const
{
	return _polygons.size();
}

size_t Model::GetVertexCount() const
{
	return _vertices.size();
}

void Model::AddVertex(float x, float y, float z)
{
	Vertex temp(x, y, z, 1);
	_vertices.push_back(temp);
}

void Model::AddPolygon(int i0, int i1, int i2)
{
	Polygon3D temp(i0, i1, i2);
	_polygons.push_back(temp);
}

void Model::ApplyTransformToLocalVertices(const Matrix &transform)
{
	_transform.clear();
	int verticesSize = int(_vertices.size());
	for (int i = 0; i < verticesSize; i++)
	{
		_transform.push_back(transform * _vertices[i]);
	}
}

void Model::ApplyTransformToTransformedVertices(const Matrix &transform)
{
	int transformSize = int(_transform.size());
	for (int i = 0; i < transformSize; i++)
	{
		_transform[i] = transform * _transform[i];
	}
}

void Model::Dehomogenize()
{
	int transformSize = int(_transform.size());
	for (int i = 0; i < transformSize; i++)
	{
		_transform[i].Dehomogenize();
	}
}

void Model::CalculateBackfaces(Camera camera)
{
	//TODO : Similar to the philosofy of drawwireframe, create a method that for each triangle will calculate if this triangle is culled or not
	std::vector <Vertex> _vertex(GetTransform());
	std::vector<Polygon3D> _polygon(GetPolygons());
	int polygonSize = int(_polygons.size());
	for (int i = 0; i < polygonSize; i++)
	{
		//Get the indices and vertexes
		Vertex vertex0 = _vertex[_polygon[i].GetIndex(0)],
			vertex1 = _vertex[_polygon[i].GetIndex(1)],
			vertex2 = _vertex[_polygon[i].GetIndex(2)];

		//Contructing vectors by subtracting vertices
		Vector3D vector1 = {vertex1.GetX() - vertex0.GetX(), vertex1.GetY() - vertex0.GetY(), vertex1.GetZ() - vertex0.GetZ()};
		Vector3D vector2 = {vertex2.GetX() - vertex0.GetX(), vertex2.GetY() - vertex0.GetY(), vertex2.GetZ() - vertex0.GetZ()};
		_polygons[i].SetNormal(Vector3D(vector1.GetY() * vector2.GetZ() - vector1.GetZ() * vector2.GetY(), 
			vector1.GetZ() * vector2.GetX()- vector1.GetX() * vector2.GetZ(),
			vector1.GetX() * vector2.GetY() - vector1.GetY() * vector2.GetX()));

		//Calculating the normal (cross product) between the two vectors
		Vector3D normal = _polygons[i].GetNormal();

		//Creating an eye-vector by subtracting the camera position from vertex0
		Vector3D eyeVector = { vertex0.GetX() - camera.GetPos().GetX(),
			vertex0.GetY() - camera.GetPos().GetY(),
			vertex0.GetZ() - camera.GetPos().GetZ()
		};
		
		//Calculate the dot product and check it
		bool cull;
		if (float DotProduct = normal.DotProduct(eyeVector) < 0)
		{
			//Flag this polygon for culling
			cull = true;
			_polygons[i].SetCull(cull);
		}
		else
		{
			//Flag the polygon to not be culled any more, so it can be displayed when it rotates round
			cull = false;
			_polygons[i].SetCull(cull);
		}
	}
}
		
void Model::Sort(void)
{
	//Create a method for sorting the polygons	
}
